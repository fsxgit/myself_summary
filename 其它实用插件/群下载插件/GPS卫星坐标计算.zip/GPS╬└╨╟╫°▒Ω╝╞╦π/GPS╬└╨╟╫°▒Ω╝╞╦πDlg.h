// GPS�����������Dlg.h : header file
//

#if !defined(AFX_GPSDLG_H__26674194_D66A_4618_BE6B_7D728FA4468B__INCLUDED_)
#define AFX_GPSDLG_H__26674194_D66A_4618_BE6B_7D728FA4468B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CGPSDlg dialog

#define PI 3.141592653589793238462643383279502884197169399375105820974944

//����һ���������࣬ÿ15min��Ӧһ��������
struct EphemerisBlock
{ 
	int PRN;//PRN��
	double a0,a1,a2;//������
	double ADOE,Crs,Deltan,M0;// �ڶ���
	double Cuc,e,Cus,SqrtA;// ������
	double Toe,Cic,OMEGA0,Cis;// ������
	double i0,Crc,omega,OMEGAdot;// ������
	double IDOT,WN;// ������
	double AODC;// �ڰ���
};


class CGPSDlg : public CDialog
{
// Construction
public:
	CGPSDlg(CWnd* pParent = NULL);	// standard constructor
	EphemerisBlock *m_Ephemeris;
	int ReadEphemerisFile(CString strPath,int &m_EphemerisBlockNum);
    CStdioFile file; 
	CString strPath;
	CString  strLine;
	int m_EphemerisBlockNum;
	
	
	//�������

	int PRN;//PRN��
    int year,month,day,hour,minute;
	double second;//GPSʱ
	double a0,a1,a2;//������
	double ADOE,Crs,Deltan,M0;// �ڶ���
	double Cuc,e,Cus,SqrtA;// ������
	double Toe,Cic,OMEGA0,Cis;// ������
	double i0,Crc,omega,OMEGAdot;// ������
	double IDOT,L2C,WN,L2P;// ������
	double SatAccuracy,SatHealth,TGD,AODC;// �ڰ���


// Dialog Data
	//{{AFX_DATA(CGPSDlg)
	enum { IDD = IDD_GPS_DIALOG };
	int		m_Day;
	int		m_Hour;
	int		m_Minute;
	int		m_Month;
	int		m_Prn;
	double	m_Second;
	double	m_X;
	double	m_Y;
	int		m_Year;
	double	m_Z;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGPSDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	void Calc(int year,int month,int day,int hour,int minute,double second,int Prn);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CGPSDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnOpen();
	afx_msg void OnSave();
	afx_msg void OnCalCulator();
	afx_msg void OnAbout();
	afx_msg void OnExit();
	afx_msg void OnIntroduction();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GPSDLG_H__26674194_D66A_4618_BE6B_7D728FA4468B__INCLUDED_)
