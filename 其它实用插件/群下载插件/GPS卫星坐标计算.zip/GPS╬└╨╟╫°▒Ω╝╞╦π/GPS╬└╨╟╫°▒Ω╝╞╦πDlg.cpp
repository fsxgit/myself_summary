// GPS�����������Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "GPS�����������.h"
#include "GPSTime.h"
#include "GPS�����������Dlg.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGPSDlg dialog

CGPSDlg::CGPSDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGPSDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGPSDlg)
	m_Day = 0;
	m_Hour = 0;
	m_Minute = 0;
	m_Month = 0;
	m_Prn = 0;
	m_Second = 0.0;
	m_X = 0.0;
	m_Y = 0.0;
	m_Year = 0;
	m_Z = 0.0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGPSDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGPSDlg)
	DDX_Text(pDX, IDC_DAY, m_Day);
	DDX_Text(pDX, IDC_HOUR, m_Hour);
	DDX_Text(pDX, IDC_MINUTE, m_Minute);
	DDX_Text(pDX, IDC_MONTH, m_Month);
	DDX_Text(pDX, IDC_PRN, m_Prn);
	DDX_Text(pDX, IDC_SECOND, m_Second);
	DDX_Text(pDX, IDC_X, m_X);
	DDX_Text(pDX, IDC_Y, m_Y);
	DDX_Text(pDX, IDC_YEAR, m_Year);
	DDX_Text(pDX, IDC_Z, m_Z);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGPSDlg, CDialog)
	//{{AFX_MSG_MAP(CGPSDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnOpen)
	ON_BN_CLICKED(IDC_BUTTON2, OnSave)
	ON_BN_CLICKED(IDC_BUTTON3, OnCalCulator)
	ON_BN_CLICKED(IDC_BUTTON4, OnAbout)
	ON_BN_CLICKED(IDC_BUTTON5, OnExit)
	ON_BN_CLICKED(IDC_BUTTON6, OnIntroduction)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGPSDlg message handlers

BOOL CGPSDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}


void CGPSDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGPSDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGPSDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CGPSDlg::OnOpen() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(true);
    dlg.m_ofn.lpstrFilter="*.txt",NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,"Data File (*.txt)|*.txt|All File (*.*)|*.*||";
	if(dlg.DoModal()==IDOK)
	{
        strPath = dlg.GetPathName();
		SetDlgItemText(IDC_EDIT1,strPath);
	}
}

int CGPSDlg::ReadEphemerisFile(CString strPath,int &m_EphemerisBlockNum)
{
	//��ȡ�ļ�
	CStdioFile file(strPath,CFile::modeRead);
	if(!file.ReadString(strLine))
		return 0;
	
	//Ѱ��Header
    int HeadLineNum=0;
    while(file.ReadString(strLine))
	{
		HeadLineNum++;
		int index=strLine.Find("END OF HEADER");
		if( -1!=index)
			break;
	}
	

	//������������
	int AllNum=0;
	while(file.ReadString(strLine))
	{
		file.ReadString(strLine);
		AllNum++;
	}
	m_EphemerisBlockNum=(AllNum+1)/8;
	m_Ephemeris=new EphemerisBlock[m_EphemerisBlockNum];
	CGpsTime  *pGpsTime = new CGpsTime[m_EphemerisBlockNum];
	if(!m_Ephemeris || !pGpsTime)
		return 0;
	file.SeekToBegin();
	for(int i=0;i<HeadLineNum;i++)
		file.ReadString(strLine);
	

	//��������
	for(i=0;i<m_EphemerisBlockNum;i++)
	{
		file.ReadString(strLine);
		strLine.Replace('D','e');
		sscanf(strLine,"%d,%d,%d,%d,%d,%d,%1f,%1f,%1f",&PRN,&year,&month,&day,&hour,&minute,&second,&a0,&a1,&a2);

		year+=2000;
        pGpsTime[i].InitgGpsTime(year, month, day, hour, minute, second);


		file.ReadString(strLine);
		strLine.Replace('D','e');
		sscanf(strLine,"%1f,%1f,%1f,%1f",&ADOE,&Crs,&Deltan,&M0);

		file.ReadString(strLine);
		strLine.Replace('D','e');
		sscanf(strLine,"%1f,%1f,%1f,%1f",&Cuc,&e,&Cus,&SqrtA);

		file.ReadString(strLine);
		strLine.Replace('D','e');
		sscanf(strLine,"%1f,%1f,%1f,%1f",&Toe,&Cic,&OMEGA0,&Cis);

		file.ReadString(strLine);
		strLine.Replace('D','e');
		sscanf(strLine,"%1f,%1f,%1f,%1f",&i0,&Crc,&omega,&OMEGAdot);

		file.ReadString(strLine);
		strLine.Replace('D','e');
		sscanf(strLine,"%1f,%1f,%1f,%1f",&IDOT,&L2C,&WN,&L2P);

		file.ReadString(strLine);
		strLine.Replace('D','e');
		sscanf(strLine,"%1f,%1f,%1f,%1f",&SatAccuracy,&SatHealth,&TGD,&AODC);

		file.ReadString(strLine);


		//��ֵ

		m_Ephemeris[i].PRN=PRN;
		m_Ephemeris[i].a0=a0;
		m_Ephemeris[i].a1=a1;
		m_Ephemeris[i].a2=a2;
		m_Ephemeris[i].ADOE=ADOE;
		m_Ephemeris[i].Crs=Crs;
		m_Ephemeris[i].e=e;
		m_Ephemeris[i].Cus=Cus;
		m_Ephemeris[i].SqrtA=SqrtA;
		m_Ephemeris[i].Toe=Toe;
		m_Ephemeris[i].Cic=Cic;
		m_Ephemeris[i].OMEGA0=OMEGA0;
		m_Ephemeris[i].Cis=Cis;
		m_Ephemeris[i].i0=i0;
		m_Ephemeris[i].Crc=Crc;
		m_Ephemeris[i].omega=omega;
		m_Ephemeris[i].OMEGAdot=OMEGAdot;
		m_Ephemeris[i].IDOT=IDOT;
		m_Ephemeris[i].WN=WN;
		m_Ephemeris[i].AODC=AODC;

	}

	file.Close();

	if(pGpsTime)
	{
		delete []pGpsTime;
		pGpsTime = NULL;
	}

	return 1;
}


void CGPSDlg::Calc(int year,int month,int day,int hour,int minute,double second,int Prn)
{
	int k=0;
	ReadEphemerisFile(strPath,m_EphemerisBlockNum);

	CGpsTime GpsTime;
	double s=GpsTime.InitgGpsTime(year,month,day,hour,minute,second);
	double t=GpsTime.GetWeekSecond();
	for(k=0;k<m_EphemerisBlockNum;k++)
	{
		if(Prn==m_Ephemeris[k].PRN && t-m_Ephemeris[k].Toe<7200) break;
		else continue;
	}
	if(k>=m_EphemerisBlockNum-1)
		MessageBox("����ʧ�ܣ�û���ҵ���Ӧ����","֪ͨ",MB_OKCANCEL);
	else{
	
	//���������˶���ƽ�����ٶ�n
	double n0;		//�ο�ʱ��TOEƽ�����ٶ�
	const double GM=3.968004415*pow(10,14);      //����������������
	n0=sqrt(GM)/pow(m_Ephemeris[k].SqrtA,3);
	double n;
	n=n0+m_Ephemeris[k].Deltan;

    //����۲�˲�����ǵ�ƽ�����M
	double tk;
	tk=t-m_Ephemeris[k].Toe;//�滮�۲�ʱ��
	if(tk>302400) tk-=604800;
	else if(tk<-302400) tk+=604800;

	//�۲�˲�����ǵ�ƽ�����M
	double M;     
	M=m_Ephemeris[k].M0+n*tk;

    //����ƫ�����E
	double E0,E;
	E0=M;
	while(1)
	{
		E=M+m_Ephemeris[k].e*sin(E0);
		if(fabs(E-E0)<pow(10,-10))	//������⣬ֱ�����С��10��-10�η�
			break;
		else
		{
			E0=E;
		}
	}

	//����������V
	double V,cosV,sinV;
	cosV=(cos(E)-m_Ephemeris[k].e)/(1-m_Ephemeris[k].e*cos(E));
	sinV=sqrt(1-m_Ephemeris[k].e*m_Ephemeris[k].e)*sin(E)/(1-m_Ephemeris[k].e*cos(E));
	V=atan((sqrt(1-m_Ephemeris[k].e*m_Ephemeris[k].e)*sin(E))/(cos(E)-m_Ephemeris[k].e));

	//�����������uu
	double uu;
	uu=V+m_Ephemeris[k].omega;

	//�����㶯������
	double du,dr,di;
	du=m_Ephemeris[k].Cuc*cos(2*uu)+m_Ephemeris[k].Cus*sin(2*uu);
	dr=m_Ephemeris[k].Crc*cos(2*uu)+m_Ephemeris[k].Crs*sin(2*uu);
	di=m_Ephemeris[k].Cic*cos(2*uu)+m_Ephemeris[k].Cis*sin(2*uu);

	//������������u��r��i
	double u,r,i;
	u=uu+du;
	r=m_Ephemeris[k].SqrtA*m_Ephemeris[k].SqrtA*(1-m_Ephemeris[k].e*cos(E))+dr;
	i=m_Ephemeris[k].i0+di+m_Ephemeris[k].IDOT*tk;

	//���������ڹ������ϵ��λ��
	double x,y,z;
	x=r*cos(u);
	y=r*sin(u);
	z=0;

	//��ؾ���
	double L;
	const double We=7.292115*pow(0.1,5);
	L=m_Ephemeris[k].OMEGA0+m_Ephemeris[k].OMEGAdot*tk-We*t;

	//����������WGS-84�е�λ������
	double X,Y,Z;
	X=x*cos(L)-y*cos(i)*sin(L);
	Y=x*sin(L)+y*cos(i)*cos(L);
	Z=y*sin(i);
	}

}

void CGPSDlg::OnSave() 
{
	// TODO: Add your control notification handler code here

}


void CGPSDlg::OnCalCulator() 
{
	// TODO: Add your control notification handler code here
	ReadEphemerisFile(strPath,m_EphemerisBlockNum);
	UpdateData(true);
	Calc(m_Year,m_Month,m_Day,m_Hour,m_Minute,m_Second,m_Prn);
	UpdateData(false);

}

void CGPSDlg::OnAbout() 
{
	// TODO: Add your control notification handler code here
	MessageBox("GPS����������� 1.0 Bata��\n     ��Ȩ���У�����ؾ���\n      @ 21313120 �ܾ�","����");
}

void CGPSDlg::OnExit() 
{
	// TODO: Add your control notification handler code here
	if (MessageBox("ȷʵҪ�˳���", "��ʾ", MB_OKCANCEL|MB_ICONWARNING) == IDOK)  
    {  
        CDialog::OnCancel();  
    }  
}

void CGPSDlg::OnIntroduction() 
{
	// TODO: Add your control notification handler code here
	MessageBox("       GPS�����������ʹ��˵��\n\n1.��������ļ���ť��������㲥����\n2.��������㡱��ť����ʼ��������\n3.��������\n\n   ��Ȩ����@ 21313120�ܾ� 2016","ʹ��˵��");
}
