class CGpsTime 
{
public:
	CGpsTime();
	CGpsTime (const CGpsTime& gtGpsTime);
	~CGpsTime();
	
	int InitgGpsTime(int nGpsWeek, double dGpsSecond);//ʹ��GPS�ܺ����ʼ��
	int InitgGpsTime (int nYear, int nMonth, int nDay, int nHour, int nMinute, double dSecond);
	int GetWeek () const{return m_nWeek;};
	double GetWeekSecond () const{return m_dWeekSecond;};
		
private: 
	int m_nWeek;
	double m_dWeekSecond;	
};